@javax.xml.bind.annotation.XmlSchema(namespace = "urn:sap-com:document:sap:soap:functions:mc-style")
package other.hht.product;
