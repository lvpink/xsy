package other.hht.bank;
/**
*
* @author XSY
* @Description 常量类
*/
public final class Constants{
   /** @Description 私有化构造方法
    */
   private Constants(){};
   /**SAP用户名*/
   public  static final String USERNAME = "D00CRM";
   /**SAP密码*/
   public  static final String PASSWORD = "Sap@123456";
    
}
